> # Update Information (Latest listed first)
> ### 1.1.7
> - Fix sizing issue that randomly started. Not sure why, as I didn't touch the assets at all. Wonder how long this has
    been fucked up and no one said anything? :D
> - Add localization to the mod, so you can now create files with a naming convention of `DeedsOfUtgard.Spanish.yml` for
    any language and localize the mod. Read the description for the keys.
> ### 1.1.6
> - Update for Valheim 0.217.14 (Hildir's Request)
> ### 1.1.5
> - Update for Valheim 0.216.9
> ### 1.1.4
> - Internal Update
> ### 1.1.3
> - Update for Mistlands
> ### 1.1.2
> - Update ServerSync internally.
> ### 1.1.1
> - Update ServerSync
> ### v1.0.0
> - Initial Release