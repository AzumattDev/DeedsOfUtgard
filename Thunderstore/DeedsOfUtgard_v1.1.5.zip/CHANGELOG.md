> # Update Information (Latest listed first)
> ### 1.1.5
> - Update for Valheim 0.216.9
> ### 1.1.4
> - Internal Update
> ### 1.1.3
> - Update for Mistlands
> ### 1.1.2
> - Update ServerSync internally.
> ### 1.1.1
> - Update ServerSync
> ### v1.0.0
> - Initial Release